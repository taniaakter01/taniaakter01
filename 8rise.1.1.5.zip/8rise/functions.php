<?php
/**
 * functions includes
 *
 * @since 8rise Theme 1.0
 */
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
 
require_once('includes/fe-free-settings.php');

function eightrise_index_hook() {
	do_action('eightrise_index_hook');
}

function eightrise_display_free_index() {
    get_template_part( 'templates/eightrise-index', 'template' );
};
add_action('eightrise_index_hook', 'eightrise_display_free_index' );

function eightrise_header_hook() {
	do_action('eightrise_header_hook');
}

function eightrise_display_free_header() {
    get_template_part( 'templates/eightrise-header', 'template' );
};
add_action('eightrise_header_hook', 'eightrise_display_free_header' );

function eightrise_footer_hook() {
	do_action('eightrise_footer_hook');
}

function eightrise_display_free_footer() {
    get_template_part( 'templates/eightrise-footer', 'template' );
};
add_action('eightrise_footer_hook', 'eightrise_display_free_footer' );
