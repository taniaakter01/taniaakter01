<!DOCTYPE html>

<html <?php language_attributes(); ?>>

<head>

<?php wp_head();

$count_posts = wp_count_posts()->publish; ?>

</head>

<?php eightrise_header_hook();