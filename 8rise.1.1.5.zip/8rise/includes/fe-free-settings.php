<?php
/**
 * Free theme settings
 *
 * @since 8rise Theme 1.0
 */

if ( ! isset( $eightrise_content_width ) )
    $eightrise_content_width = 900;

/**
* Stylesheets enqueue
*/
 
function eightrise_scripts() {		
    wp_enqueue_style('eightrise-main-style', get_template_directory_uri() . '/style.css', array(), filemtime(get_template_directory() . '/style.css'), false);

	wp_enqueue_script( 'eightrise-primary-navigation', get_template_directory_uri() . '/js/eightrise-primary-navigation.js', array(), '20211228', true );
    wp_enqueue_script( 'eightrise-stickyHeader', get_template_directory_uri() . '/js/eightrise-sticky-header.js', array(), '20190715', true );

	wp_enqueue_style( 'dashicons');
    wp_enqueue_style( 'genericons');
    $font2 = get_template_directory_uri() . '/fonts/font-awesome/css/font-awesome.css';
    wp_enqueue_style( 'eightrise-font-awesome', $font2,'','');
	$font3 = get_template_directory_uri() . '/fonts/genericons-neue/Genericons-Neue.css';
	wp_enqueue_style( 'eightrise-genericons-neue', $font3, '', '');
	
	if ( is_singular() ) wp_enqueue_script( "comment-reply" );
}
add_action( 'wp_enqueue_scripts', 'eightrise_scripts' );

add_theme_support( 'admin-bar', array( 'callback' => '__return_false' ) );
add_theme_support( 'automatic-feed-links' );
add_theme_support( "wp-block-styles" );
add_theme_support( "responsive-embeds" );
add_theme_support( 'html5', array(
    // Any or all of these.
    'comment-list', 
    'comment-form',
    'search-form',
    'gallery',
    'caption',
) );
add_theme_support( "custom-logo");
add_theme_support( "custom-header" );
add_theme_support( "custom-background");
add_theme_support( "align-wide" );


/**
 * Add a button to top-level menu items that has sub-menus.
 * An icon is added using CSS depending on the value of aria-expanded.
 *
 * @since 1.0.0
 *
 * @param string $output Nav menu item start element.
 * @param object $item   Nav menu item.
 * @param int    $depth  Depth.
 * @param object $args   Nav menu args.
 *
 * @return string Nav menu item start element.
 */
function eightrise_add_sub_menu_toggle( $output, $item, $depth, $args ) {
	if ( 0 === $depth && in_array( 'menu-item-has-children', $item->classes, true ) ) {

		// Add toggle button.
		$output .= '<button class="sub-menu-toggle" aria-expanded="false" onClick="eightriseExpandSubMenu(this)">';
		$output .= '<span class="icon-minus dashicons dashicons-arrow-down oppositecolortxt1"></span>';
		$output .= '<span class="icon-plus dashicons dashicons-arrow-up oppositecolortxt1"></span>';        
		$output .= '<span class="screen-reader-text">' . esc_html__( 'Open menu', '8rise' ) . '</span>';
		$output .= '</button>';
	}
	return $output;
}
add_filter( 'walker_nav_menu_start_el', 'eightrise_add_sub_menu_toggle', 10, 4 );


/**
* Widget Areas                                                                                                          
*/

function eightrise_widgets_init() {
	
	if ( function_exists('register_sidebar') )
	  register_sidebar(array(
		'name' => 'Post Sidebar Widgets',
		'id' => 'sidebar-1',
		'before_widget' => '<div class = "widgetizedArea">',
		'after_widget' => '</div>',
		'before_title' => '<h3>',
		'after_title' => '</h3>',
	  )
	);
}
add_action( 'widgets_init', 'eightrise_widgets_init' );	

/**
* Theme language
*/

function eightrise_theme_setup(){

    load_theme_textdomain( '8rise', get_template_directory() . '/languages' );	
	
	$locale = get_locale();
    $locale_file = get_template_directory() . "/languages/$locale.php";

    if ( is_readable( $locale_file ) ) {
        get_template_part( $locale_file );
    }
}
add_action( 'after_setup_theme', 'eightrise_theme_setup' );

/**
* Customize menus
*/

function eightrise_menus() {
  register_nav_menus(
    array(
      'header-menu' => __( 'Header Menu', '8rise' ),
      'social-menu' => __( 'Social Menu', '8rise' ),	  
      'extra-menu' => __( 'Extra Menu', '8rise' ),
	  'footer-menu' => __( 'Footer Menu', '8rise' )
    )
  );
}
add_action( 'init', 'eightrise_menus' );

function eightrise_add_additional_class_on_li($classes, $item, $args) {
    if(isset($args->add_li_class)) {
        $classes[] = $args->add_li_class;
    }
    return $classes;
}
add_filter('nav_menu_css_class', 'eightrise_add_additional_class_on_li', 1, 3);

function eightrise_add_additional_class_on_a($classes, $item, $args) {
    if(isset($args->add_a_class)) {
        $classes['class'] = $args->add_a_class;
    }
    return $classes;
}
add_filter('nav_menu_link_attributes', 'eightrise_add_additional_class_on_a', 1, 3);

/**
* Enable thumbnails
*/

add_theme_support('post-thumbnails');

// Add other useful image sizes for use through Add Media modal
add_image_size( 'eightrise-thumbnail512', 512, 512, true );
add_image_size( 'eightrise-thumbnail128', 128, 128, true );
add_image_size( 'eightrise-defaultmaxsize', 1200, 1080 );
add_image_size( 'eightrise-fullhd', 1920, 1080, true );

// Register the three useful image sizes for use in Add Media modal
add_filter( 'image_size_names_choose', 'eightrise_custom_sizes' );
function eightrise_custom_sizes( $sizes ) {
    return array_merge( $sizes, array(
        'eightrise-thumbnail512' => __( 'Thumbnail 512 x 512', '8rise' ),
		'eightrise-thumbnail128' => __( 'Thumbnail 128 x 128', '8rise' ),		
        'eightrise-defaultmaxsize' => __( 'Default max size', '8rise' ),			
        'eightrise-fullhd' => __( 'Full HD', '8rise' ),
    ) );
}

add_filter( 'the_title', 'eightrise_trim_words' );

function eightrise_trim_words( $title )
{
    // limit to ten words
    return wp_trim_words( $title, 10, '...' );
}

/**
* title tag 
*/

function eightrise_title_tag(){
    add_theme_support( 'title-tag' );
}
add_action( 'after_setup_theme', 'eightrise_title_tag' );

/**
* Add custom to head 
*/

function eightrise_custom_head() {
	?>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="UTF-8">
	<?php
}
add_action( 'wp_head', 'eightrise_custom_head' );

function eightrise_comment_nav() { 
    // Are there comments to navigate through? 
    if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : 
    ?> 
    <nav class="navigation comment-navigation" role="navigation"> 
        <h2 class="screen-reader-text"><?php __( 'Comment navigation', '8rise' ); ?></h2> 
        <div class="nav-links"> 
            <?php 
                if ( $prev_link = get_previous_comments_link( __( 'Older Comments', '8rise' ) ) ) : 
                    printf( '<div class="nav-previous">%s</div>', esc_html($prev_link) ); 
                endif; 
 
                if ( $next_link = get_next_comments_link( __( 'Newer Comments', '8rise' ) ) ) : 
                    printf( '<div class="nav-next">%s</div>', esc_html($next_link) ); 
                endif; 
            ?> 
        </div><!-- .nav-links --> 
    </nav><!-- .comment-navigation --> 
    <?php 
    endif; 
} 

?>