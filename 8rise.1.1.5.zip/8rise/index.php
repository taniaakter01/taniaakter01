<?php
	eightrise_index_hook();