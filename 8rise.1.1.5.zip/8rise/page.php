<?php
/**
 * Template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage 8rise
 * @since 8rise Theme 1.0
 */

get_header(); ?>

<script>
	
	document.body.className = document.body.className + " js_enabled";
	
</script>

<div id="page">

	<span class="anchor" id="top"></span>
    <div class="relsection toppage">
		
            	<?php
				// Start the loop.
				while ( have_posts() ) : the_post();
					the_title('<div class="titlecenter invert">', '</div>');?>
						<div class="blockfull">
							<div class="blockfull lpadding"> 
								<?php the_content();	
								// End of the loop.?>
				            </div>        
    					</div>  
				<?php endwhile; ?>
           
    </div>	

</div>

<?php get_footer(); ?>
