=== 8rise Theme ===
Contributors: romainfolio
Tags: simple, mobile-friendly 
Donate link: https://8rise.com/
Requires at least: 4.9.6
Tested up to: 5.0
Requires PHP: 5.6
Stable tag: 1.5
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/license-list.html#GPLv2

8rise Theme is a new generation theme.

== Description ==
8rise Theme is designed to show off the power of the block editor. It features custom styles for all the default blocks, and is built so that what you see in the editor looks like what you'll see on your website. Twenty Nineteen is designed to be adaptable to a wide range of websites, whether you’re running a photo blog, launching a new business, or supporting a non-profit. Featuring ample whitespace and modern sans-serif headlines paired with classic serif body text, it's built to be beautiful on all screen sizes.

For more information about 8rise Theme please go to https://one.8rise.com/.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in 8rise Theme in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
4. Go to https://one.8rise.com for a guide on how to customize this theme.
5. Navigate to Theme Options > Display in your admin panel and customize to taste.

== Copyright ==

8rise Theme WordPress Theme, Copyright 2018-2020 WordPress.org
8rise Theme is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Changelog ==

= 1.0.0 =
* Released: June 6, 2020

= 1.1.0 =
* Released: September 30, 2021
* Fixes compliance with wordpress.org

= 1.1.1 =
* Released: October 08, 2021
* Added hooks

= 1.1.2 =
* Released: January 21, 2022
* keyboard navigartion
* compatibility issues
* translatable

Initial release

== Resources ==
* normalize.css, © 2012-2018 Nicolas Gallagher and Jonathan Neal, MIT
* Underscores, © 2012-2019 Automattic, Inc., GNU GPL v2 or later

== Frequently Asked Questions ==

= Is the theme responsive ? =

Yes.

== Upgrade Notice ==

= 1.1.0 =
Upgraded needed for full plugins compatibility

= 1.1.1 =
Upgraded needed for full plugins compatibility

= 1.1.2 =
Upgraded needed for full plugins compatibility

== Screenshots ==

1. The main page

Image for theme screenshot, Copyright Romain Folio
License: CC0 1.0 Universal (CC0 1.0)
Source: https://romainfolio.com