<?php get_header(); ?>

<div id="page" class="single">
	<div class="topoffset"></div>
    <div class="relsection">
		<?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>
		
		<div class="blockgoldbig lpadding">
			
				<div class="titlecenter invert"><?php the_title(); ?></div>
				<div class="separator"></div>
				<div class="contentcenter"><?php the_content(); ?></div>
			
				<div class="sharingblock">
					<div class="sharehead"><i class="fa fa-share-alt" aria-hidden="true"></i></div>
					<a class="icon icon-facebook icon-replacement" href="http://www.facebook.com/sharer/sharer.php?s=100&p[url]=<?php echo urlencode(get_permalink()); ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
					<a class="icon icon-twitter icon-replacement" href="https://twitter.com/intent/tweet?text=<?php echo urlencode(wp_title(' -', true, 'right')); ?>+<?php echo urlencode(get_permalink()); ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
					<a class="icon icon-pinterest icon-replacement" href="https://pinterest.com/pin/create/button/?url=<?php echo urlencode(get_permalink()); ?>&amp;media=<?php wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' ); ?>&amp;description=<?php str_replace( ' ', '%20', get_the_title());?>;" target="_blank"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
					<a class="icon icon-email icon-replacement" href="mailto:?subject=I wanted you to see this&amp;body=Check out this article <?php echo urlencode(get_permalink()); ?>" title="Share by Email"><i class="fa fa-envelope" aria-hidden="true"></i></a>	
				</div>

				<?php wp_link_pages( array(
					'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', '8rise' ) . '</span>',
					'after'       => '</div>',
					'link_before' => '<span>',
					'link_after'  => '</span>',
					) );
				?>
				<div class="post-meta" style="float:left; width:100%;"><?php the_tags() ?></div>
				<div class="contentfooter"><?php esc_html_e('Published by', '8rise'); ?> <b><?php get_the_author(); ?></b> <?php esc_html_e('on the', '8rise'); ?> <b><?php echo esc_html(date("j M Y", strtotime($post ->post_date))); ?></b></div>	
				<div style="float:left;"><?php previous_post_link(); ?></div><div style="float:right;"><?php next_post_link(); ?></div>
				<div><?php  comments_template( '/templates/comments.php', true ); ?> </div>

 		</div>
		
		<?php endwhile; ?>

		<?php endif; ?>
		
		<div class="blockgoldsmall sidebar singlesidebar">
			<div class="relsection lpadding">
				<div class="smallblock">
					<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
							<?php dynamic_sidebar( 'sidebar-1' ); ?>
					<?php endif; ?>
				</div>
			</div>		
		</div>
 	</div>
    
</div>
<?php get_footer(); ?>
