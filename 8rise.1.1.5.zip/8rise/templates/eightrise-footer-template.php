<div id="footer" class="active">

	<div id="footerDrawer" class="bg-color1">
	<!--        	<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>-->
		<div class="center-footer">
			
					<?php
						wp_nav_menu( array( 
							'theme_location' => 'footer-menu', 
							'container'=> false,
							'menu_id' => 'footermenu',
							'menu_class' => 'menu',
							'add_li_class'  => 'menurow oppositecolortxt1',
							'add_a_class'  => 'oppositecolortxt1',
							'fallback_cb' => '__return_false'
						) ); 
					?>	
			
		</div>
	</div> 

</div>   

</div>

<?php wp_footer(); ?>
</body>
</html>