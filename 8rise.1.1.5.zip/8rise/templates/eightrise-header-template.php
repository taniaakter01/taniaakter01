
<body <?php body_class(); ?>>

<?php wp_body_open(); ?>

<div id="loadingbg"></div>
    
    <?php if ( is_single() || is_page() ): ?>
    <?php $pageclass = wp_title('', false, "right");
    $pageclass = preg_replace('/\s+/', '', $pageclass);
    $pageclass = strtolower($pageclass);
    ?>
    <?php endif; ?>
    
    <?php $pageclass = isset($pageclass) ? $pageclass : 'homepage'; ?>

<div id="global" class="<?php echo esc_html($pageclass); ?>" >
<a class="skip-link screen-reader-text" href="#page"><?php esc_html_e( 'Skip to content', '8rise' ); ?></a>

    <div id="header" class="bg-color1">
        
        <div id="logo">
            <div id="logoinner">
                <h1 class="site-title"><a class="oppositecolortxt1" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
            </div>
        </div>
        
        <div id="menu">
        
            <div class="menucenter">
            
                <div id="menumobilebtn">
                    
                    <div class="menurow">
                        <a href="#mobilemenu" class="activatemenu bg-color1">
                            <div class="hamburger">
                                <div class="centerbuger">
                                <span class="oppositecolorbg1"></span>
                                <span class="oppositecolorbg1"></span>
                                <span class="oppositecolorbg1"></span>
                                </div>
                            </div>
                        </a>
                    </div>
                    
                </div>
                <?php
                $user = wp_get_current_user();
                $allowed_roles = array('editor', 'administrator', 'author');
                ?>
                
                    <?php
                    
                        wp_nav_menu(
                           array( 
                               'theme_location' => 'header-menu', 
                               'container' => false,
                               'menu_id' => 'pagemenu',
                               'menu_class' => 'menu',
                               'add_li_class' => 'menurow',
                               'add_a_class' => 'bg-color1 oppositecolortxt1',
                               'fallback_cb' => '__return_false'
                           ) 
                        );

                    ?>
            </div>
        
        </div> 
        
        <div id="menucornerright">
            <div id="menucornerrightinner">

            </div>
        </div>          
        
    </div>