<?php get_header(); ?>

<script> document.body.className = document.body.className + " js_enabled";	</script>

<div id="page">
    
<div class="topoffset"></div>
<div class="relsection bg-color-light txt-color-dark">
           
    <div class="titlecenter"><?php esc_html_e('LATEST POSTS', '8rise'); ?></div>
    <div class="blockfull lpadding">

		<?php if ( have_posts() ) :
        $loop = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 8, 'orderby' => 'post_date', 'order' => 'DESC', 'category' => 'current' ) );
        while ( $loop->have_posts() ) : $loop->the_post(); ?> 		

        <a id="post-<?php the_ID(); ?>" <?php post_class("blockfourth spadding link_trigger"); ?> href="<?php the_permalink(); ?>">
        
            <div class="topline bg-color-dark"></div><div class="leftline bg-color-dark"></div>
                
            <div class="blocksquare" style="background-image:url(<?php if ( has_post_thumbnail() ) {the_post_thumbnail_url('thumbnail512');} ?>);">
                <div class="overlayview"><i class="fa fa-search" aria-hidden="true"></i></div>
                <div class="posttitlecontainer bg-color-light">

                    <div class="inner-border txt-color-dark bd-color-dark">
						<div class="posttitle"><?php echo esc_html(get_the_title()); ?></div>
						<div class="postdate bd-color-dark">
							<div class="postmonth bd-color-dark"><?php echo esc_html(date("M", strtotime($post ->post_date))); ?></div>
							<div class="postyear"><?php echo esc_html(date("Y", strtotime($post ->post_date))); ?></div>
						</div>
                    </div>
                    
                </div>
            </div>
                
            <div class="rightline bg-color-dark"></div><div class="bottomline bg-color-dark"></div>
            
        </a>
            
        <?php endwhile; ?>
		<?php endif; ?> 
    </div>              
</div>
      
</div>

<?php get_footer(); ?>